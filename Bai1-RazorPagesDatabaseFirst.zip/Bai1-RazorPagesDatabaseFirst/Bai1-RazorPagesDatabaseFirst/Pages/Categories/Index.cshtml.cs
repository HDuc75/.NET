﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Bai1_RazorPagesDatabaseFirst.Data;
using Bai1_RazorPagesDatabaseFirst.Models;

namespace Bai1_RazorPagesDatabaseFirst.Pages.Categories
{
    public class IndexModel : PageModel
    {
        private readonly Bai1_RazorPagesDatabaseFirst.Data.ECommerceContext _context;

        public IndexModel(Bai1_RazorPagesDatabaseFirst.Data.ECommerceContext context)
        {
            _context = context;
        }

        public IList<Category> Category { get;set; } = default!;

        public async Task OnGetAsync()
        {
            Category = await _context.Categories.ToListAsync();
        }
    }
}
