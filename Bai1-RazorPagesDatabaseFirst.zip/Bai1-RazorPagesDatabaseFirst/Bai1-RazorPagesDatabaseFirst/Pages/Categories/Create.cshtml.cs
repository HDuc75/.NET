﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Bai1_RazorPagesDatabaseFirst.Data;
using Bai1_RazorPagesDatabaseFirst.Models;

namespace Bai1_RazorPagesDatabaseFirst.Pages.Categories
{
    public class CreateModel : PageModel
    {
        private readonly Bai1_RazorPagesDatabaseFirst.Data.ECommerceContext _context;

        public CreateModel(Bai1_RazorPagesDatabaseFirst.Data.ECommerceContext context)
        {
            _context = context;
        }

        public IActionResult OnGet()
        {
            return Page();
        }

        [BindProperty]
        public Category Category { get; set; } = default!;

        // For more information, see https://aka.ms/RazorPagesCRUD.
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            _context.Categories.Add(Category);
            await _context.SaveChangesAsync();

            return RedirectToPage("./Index");
        }
    }
}
