﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Bai1_RazorPagesDatabaseFirst.Data;
using Bai1_RazorPagesDatabaseFirst.Models;

namespace Bai1_RazorPagesDatabaseFirst.Pages.Products
{
    public class IndexModel : PageModel
    {
        private readonly Bai1_RazorPagesDatabaseFirst.Data.ECommerceContext _context;

        public IndexModel(Bai1_RazorPagesDatabaseFirst.Data.ECommerceContext context)
        {
            _context = context;
        }

        public IList<Product> Product { get;set; } = default!;

        public async Task OnGetAsync()
        {
            Product = await _context.Products
                .Include(p => p.Category).ToListAsync();
        }
    }
}
