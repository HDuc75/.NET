﻿

using Bai1_RazorPagesCodeFirst.Models;

namespace Bai1_RazorPagesCodeFirst.Models
{
    public class Category
    {
        public int Id { get; set; }
        public string? Name { get; set; }
        public ICollection<Product>? Products { get; set; }
    }
}