﻿using Bai1_RazorPagesCodeFirst.Models;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
namespace Bai1_RazorPagesCodeFirst.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options) { }

        public DbSet<Category> Categories { get; set; }
        public DbSet<Product> Products { get; set; }
    }
}

