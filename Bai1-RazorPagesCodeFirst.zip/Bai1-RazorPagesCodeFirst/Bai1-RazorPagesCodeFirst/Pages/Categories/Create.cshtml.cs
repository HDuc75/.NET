﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Bai1_RazorPagesCodeFirst.Data;
using Bai1_RazorPagesCodeFirst.Models;

namespace Bai1_RazorPagesCodeFirst.Pages.Categories
{
    public class CreateModel : PageModel
    {
        private readonly Bai1_RazorPagesCodeFirst.Data.ApplicationDbContext _context;

        public CreateModel(Bai1_RazorPagesCodeFirst.Data.ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult OnGet()
        {
            return Page();
        }

        [BindProperty]
        public Category Category { get; set; } = default!;

        // For more information, see https://aka.ms/RazorPagesCRUD.
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            _context.Categories.Add(Category);
            await _context.SaveChangesAsync();

            return RedirectToPage("./Index");
        }
    }
}
